#import data
import open3d as o3d
import numpy as np
voxel_size = 0.02
max_correspondence_distance_coarse = voxel_size * 0.5
max_correspondence_distance_fine = voxel_size * 0.5
#Input Data
def load_point_clouds(voxel_size=0.0):
    pcds = []
    for i in range(3):
        pcd = o3d.io.read_point_cloud(r"Data/tangkifull_bin_%d.pcd" % i)
        pcd.estimate_normals()
        pcd_down = pcd.voxel_down_sample(voxel_size=voxel_size)
        pcds.append(pcd_down)
    return pcds

#1 Pemrosesan data
#Menjalankan Algoritma Point-to-Plane ICP
def pairwise_registration(source, target, 
max_correspondence_distance_coarse,
    max_correspondence_distance_fine):
    print("Apply point-to-plane ICP")
    icp_coarse = o3d.pipelines.registration.registration_icp(source, target, max_correspondence_distance_coarse, np.identity(4), o3d.pipelines.registration.TransformationEstimationPointToPlane())
    icp_fine = o3d.pipelines.registration.registration_icp(
 source, target, max_correspondence_distance_fine,
 icp_coarse.transformation,
 o3d.pipelines.registration.TransformationEstimationPointToPlane())
    transformation_icp = icp_fine.transformation
    information_icp = o3d.pipelines.registration.get_information_matrix_from_point_clouds(source, target, max_correspondence_distance_fine, icp_fine.transformation)
    print("Nilai Transformasi Pairwise Reg", icp_coarse, transformation_icp)
    return transformation_icp, information_icp
#Membangun PoseGraph
def full_registration(pcds, max_correspondence_distance_coarse,
    max_correspondence_distance_fine):
    pose_graph = o3d.pipelines.registration.PoseGraph()
    odometry = np.identity(4)
    pose_graph.nodes.append(o3d.pipelines.registration.PoseGraphNode(odometry))
    n_pcds = len(pcds)
    for source_id in range(n_pcds):
        for target_id in range(source_id + 1, n_pcds):
            transformation_icp, information_icp = pairwise_registration(
                                                        pcds[source_id], pcds[target_id],
                                                        max_correspondence_distance_coarse,
                                                        max_correspondence_distance_fine)
            print("Build o3d.pipelines.registration.PoseGraph")
            if target_id == source_id + 1: # odometry case
                odometry = np.dot(transformation_icp, odometry)
                pose_graph.nodes.append(
                    o3d.pipelines.registration.PoseGraphNode(np.linalg.inv(odometry)))
                pose_graph.edges.append(o3d.pipelines.registration.PoseGraphEdge(source_id,target_id,transformation_icp,information_icp,uncertain=False))
    else: # loop closure case
        pose_graph.edges.append(
o3d.pipelines.registration.PoseGraphEdge(source_id,
target_id,
transformation_icp,
information_icp,
uncertain=True))
    print("Nilai Transformasi Full Reg", transformation_icp)
    return pose_graph
if __name__ == "__main__":
    voxel_size = 0.02
    pcds_down = load_point_clouds(voxel_size)
    o3d.visualization.draw(pcds_down)



#2 Pemrosesan data
    print("Full registration ...")
    max_correspondence_distance_coarse = voxel_size * 15
    max_correspondence_distance_fine = voxel_size * 1.5
    with o3d.utility.VerbosityContextManager(o3d.utility.VerbosityLevel.Debug) as cm:
        pose_graph = full_registration(pcds_down, max_correspondence_distance_coarse, max_correspondence_distance_fine)
    print("Optimizing PoseGraph ...")
    option = o3d.pipelines.registration.GlobalOptimizationOption(max_correspondence_distance=max_correspondence_distance_fine,edge_prune_threshold=0.25,reference_node=0)
    with o3d.utility.VerbosityContextManager(o3d.utility.VerbosityLevel.Debug) as cm:
        o3d.pipelines.registration.global_optimization(pose_graph, o3d.pipelines.registration.GlobalOptimizationLevenbergMarquardt(), o3d.pipelines.registration.GlobalOptimizationConvergenceCriteria(), option)


#Visualisasi dan Export Hasil
    print("Transform points and display")
    for point_id in range(len(pcds_down)):
        print(pose_graph.nodes[point_id].pose)
        pcds_down[point_id].transform(pose_graph.nodes[point_id].pose)
        o3d.visualization.draw(pcds_down)
        # Menyimpan hasil registrasi
o3d.io.write_point_cloud("R1.pcd", pcds_down[0])
o3d.io.write_point_cloud("R2.pcd", pcds_down[1])
o3d.io.write_point_cloud("R3.pcd", pcds_down[2])